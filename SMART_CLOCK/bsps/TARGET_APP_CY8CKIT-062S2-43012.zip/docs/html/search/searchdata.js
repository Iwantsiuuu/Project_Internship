var indexSectionsWithContent =
{
  0: "abcefjlmpw",
  1: "c",
  2: "c",
  3: "abcefjlpw",
  4: "cmp"
};

var indexSectionNames =
{
  0: "all",
  1: "functions",
  2: "variables",
  3: "groups",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Functions",
  2: "Variables",
  3: "Modules",
  4: "Pages"
};

